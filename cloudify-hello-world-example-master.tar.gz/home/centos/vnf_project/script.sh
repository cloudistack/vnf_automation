#!/bin/bash

ls
cfy blueprints list 
cfy blueprints upload https://github.com/cloudistack/vnf_automation/cloudify-hello-world-example-master/openstack.yaml
cfy deployments create -b cloudify-hello-world-example-master -i "region=RegionOne;external_network_name=provider;flavor=b829690f-f7de-4487-aee0-1eb46f377405;image=b0761018-de62-486b-aaa4-4aa3a2afa6bd"
cfy executions start install -d cloudify-hello-world-example-master
